import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const line1Ref = useRef<HTMLDivElement>(null);
  const line2Ref = useRef<HTMLDivElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const leftLabelRef = useRef<HTMLDivElement>(null);
  const rightLabelRef = useRef<HTMLDivElement>(null);
  const scrollIndicatorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const line1 = line1Ref.current;
    const line2 = line2Ref.current;
    const portrait = portraitRef.current;
    const leftLabel = leftLabelRef.current;
    const rightLabel = rightLabelRef.current;
    const scrollIndicator = scrollIndicatorRef.current;

    if (!section || !headline || !portrait || !line1 || !line2) return;

    const ctx = gsap.context(() => {
      // Split characters for kinetic animation
      const chars1 = line1.querySelectorAll('.char');
      const chars2 = line2.querySelectorAll('.char');

      // Entrance timeline: dramatic staggered letter rise & reveal
      const tl = gsap.timeline({ delay: 0.15 });

      tl.fromTo(
        [...chars1, ...chars2],
        {
          yPercent: 120,
          opacity: 0,
          rotateX: -60,
          filter: 'blur(12px)',
        },
        {
          yPercent: 0,
          opacity: 1,
          rotateX: 0,
          filter: 'blur(0px)',
          duration: 1.1,
          stagger: {
            each: 0.035,
            from: 'center',
          },
          ease: 'power4.out',
        }
      )
        .fromTo(
          portrait,
          { y: 80, opacity: 0, scale: 0.95 },
          { y: 0, opacity: 1, scale: 1, duration: 1.3, ease: 'power3.out' },
          '-=0.8'
        )
        .fromTo(
          [leftLabel, rightLabel, scrollIndicator],
          { opacity: 0, y: 15 },
          { opacity: 1, y: 0, duration: 0.7, stagger: 0.1, ease: 'power2.out' },
          '-=0.5'
        );

      // Continuous subtle breathing kinetic oscillation for background typography
      gsap.to(line1, {
        y: -12,
        duration: 3.5,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });

      gsap.to(line2, {
        y: 12,
        duration: 4,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });

      // Scroll-driven parallax & animated letter-spacing expansion
      gsap.to(headline, {
        yPercent: -35,
        letterSpacing: '0.04em',
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });

      gsap.to(portrait, {
        yPercent: -15,
        scale: 1.05,
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });

      gsap.to([leftLabel, rightLabel, scrollIndicator], {
        opacity: 0,
        y: -20,
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '30% top',
          scrub: true,
        },
      });
    }, sectionRef);

    // Interactive mouse parallax tilt on desktop
    const handleMouseMove = (e: MouseEvent) => {
      if (window.innerWidth < 768) return;
      const xNorm = (e.clientX / window.innerWidth - 0.5) * 2;
      const yNorm = (e.clientY / window.innerHeight - 0.5) * 2;

      if (headline) {
        gsap.to(headline, {
          x: xNorm * 16,
          y: yNorm * 8,
          duration: 1.2,
          ease: 'power2.out',
        });
      }
      if (portrait) {
        gsap.to(portrait, {
          x: xNorm * -10,
          y: yNorm * -6,
          duration: 1.4,
          ease: 'power2.out',
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      ctx.revert();
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const splitText = (text: string) => {
    return text.split('').map((char, i) => (
      <span key={i} className="char inline-block will-change-transform">
        {char === ' ' ? '\u00A0' : char}
      </span>
    ));
  };

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative w-full min-h-screen bg-[#EDECE8] text-[#0D0D0F] flex flex-col justify-between overflow-hidden pt-28 pb-10 select-none"
    >
      {/* Film Grain Texture */}
      <div className="absolute inset-0 pointer-events-none film-grain" />

      {/* Main Composition: Layered Typography & Real Cutout Portrait */}
      <div className="relative flex-1 w-full max-w-7xl mx-auto px-6 md:px-12 flex flex-col justify-center items-center">
        {/* Animated Massive Centred Typography (Layer 1 - Behind Portrait) */}
        <div
          ref={headlineRef}
          className="relative z-10 w-full text-center flex flex-col items-center justify-center font-display font-black tracking-tighter uppercase leading-[0.82] perspective-1000"
        >
          <div ref={line1Ref} className="overflow-hidden block text-[14vw] lg:text-[13vw]">
            {splitText('ABHIGYAN')}
          </div>
          <div ref={line2Ref} className="overflow-hidden block text-[14vw] lg:text-[13vw]">
            {splitText('KALITA.')}
          </div>
        </div>

        {/* Real Cutout Photograph in Centre Foreground (Layer 2 - Overlapping Typography) */}
        <div
          ref={portraitRef}
          className="absolute z-20 bottom-0 w-[280px] sm:w-[340px] md:w-[420px] lg:w-[470px] pointer-events-none flex items-end justify-center"
        >
          <img
            src="/abhigyan-cutout.png"
            alt="Abhigyan Kalita"
            className="w-full h-auto object-contain select-none pointer-events-none drop-shadow-[0_15px_30px_rgba(13,13,15,0.18)]"
            loading="eager"
            draggable={false}
          />
        </div>

        {/* Minimal Editorial Text Left & Right */}
        <div className="absolute inset-x-6 md:inset-x-12 bottom-16 z-30 flex items-end justify-between pointer-events-none">
          {/* Left Minimal Editorial Text */}
          <div
            ref={leftLabelRef}
            className="text-[10px] sm:text-xs font-mono tracking-widest uppercase text-[#262629] font-medium"
          >
            <span className="block text-[#A6A6A6] text-[9px] mb-0.5">01 / ROLE</span>
            CREATIVE DEVELOPER
          </div>

          {/* Right Minimal Editorial Text */}
          <div
            ref={rightLabelRef}
            className="text-[10px] sm:text-xs font-mono tracking-widest uppercase text-[#262629] font-medium text-right"
          >
            <span className="block text-[#A6A6A6] text-[9px] mb-0.5">02 / REGION</span>
            INDIA • WORLDWIDE
          </div>
        </div>
      </div>

      {/* Minimal Bottom Scroll Indicator */}
      <div
        ref={scrollIndicatorRef}
        className="relative z-30 w-full flex flex-col items-center justify-center space-y-1.5 text-[#262629] pt-2"
      >
        <span className="text-[9px] font-mono tracking-[0.3em] uppercase text-[#A6A6A6]">
          SCROLL
        </span>
        <div className="w-4 h-7 rounded-full border border-[#262629]/30 flex items-start justify-center p-1">
          <div className="w-1 h-1.5 rounded-full bg-[#0D0D0F] animate-bounce" />
        </div>
      </div>
    </section>
  );
}
