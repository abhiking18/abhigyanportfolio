import { useState, useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, ArrowRight, ArrowLeft } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export interface ProjectData {
  id: string;
  num: string;
  title: string;
  category: string;
  url: string;
  image: string;
  description: string;
  isDemo: boolean;
}

export const projects: ProjectData[] = [
  {
    id: 'glo',
    num: '01',
    title: 'GLO Skin & Hair Clinic',
    category: 'Healthcare & Wellness',
    url: 'https://gloclinicdemo1.vercel.app/',
    image: '/project-glo.png',
    description: 'Clinical aesthetic interface with consultation scheduling.',
    isDemo: true,
  },
  {
    id: 'dhaba',
    num: '02',
    title: 'New Highway Chef Dhaba',
    category: 'Food & Hospitality',
    url: 'https://chefdhabademo16.vercel.app/',
    image: '/project-dhaba.png',
    description: 'Regional highway dining showcase with signature menus.',
    isDemo: true,
  },
  {
    id: 'realestate',
    num: '03',
    title: 'Real Estate Website',
    category: 'Real Estate',
    url: 'https://tarexwebs-sample.netlify.app/',
    image: '/project-realestate.png',
    description: 'Editorial real estate exploration for luxury architectural spaces.',
    isDemo: true,
  },
  {
    id: 'kidzee',
    num: '04',
    title: 'Kidzee Rangia',
    category: 'Education',
    url: 'https://kidzeedemo.vercel.app/',
    image: '/project-kidzee.png',
    description: 'Preschool admissions and early education learning hub.',
    isDemo: true,
  },
];

export default function SelectedProjects3D() {
  const containerRef = useRef<HTMLElement>(null);
  const pinSectionRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  // Touch swipe support
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const diff = touchStartX.current - touchEndX.current;
    if (diff > 50) {
      nextProject();
    } else if (diff < -50) {
      prevProject();
    }
    touchStartX.current = 0;
    touchEndX.current = 0;
  };

  // ScrollTrigger pinned horizontal progression
  useEffect(() => {
    const container = containerRef.current;
    const pinSection = pinSectionRef.current;
    if (!container || !pinSection) return;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: container,
        start: 'top top',
        end: `+=${projects.length * 800}`,
        pin: pinSection,
        scrub: 0.5,
        onUpdate: (self) => {
          const progress = self.progress;
          const idx = Math.min(
            projects.length - 1,
            Math.floor(progress * projects.length)
          );
          setActiveIndex(idx);
        },
      });
    }, container);

    return () => ctx.revert();
  }, []);

  const nextProject = () => {
    setActiveIndex((prev) => (prev + 1) % projects.length);
  };

  const prevProject = () => {
    setActiveIndex((prev) => (prev - 1 + projects.length) % projects.length);
  };

  const activeProject = projects[activeIndex];

  return (
    <section
      id="work"
      ref={containerRef}
      className="relative w-full bg-[#0D0D0F] text-[#EDECE8] select-none"
      style={{ height: `${(projects.length + 1) * 100}vh` }}
    >
      {/* Pinned Viewport Container */}
      <div
        ref={pinSectionRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="h-screen w-full flex flex-col justify-between py-12 md:py-16 px-6 md:px-12 overflow-hidden"
      >
        {/* Top Header Row */}
        <div className="max-w-7xl mx-auto w-full flex items-end justify-between border-b border-[#262629] pb-6">
          <div>
            <div className="flex items-center space-x-3 text-[#A6A6A6] font-mono text-xs uppercase tracking-widest mb-2">
              <span className="w-8 h-[1px] bg-[#A6A6A6]" />
              <span>Project Showcase</span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-6xl md:text-7xl tracking-tighter uppercase text-[#EDECE8]">
              SELECTED WORK.
            </h2>
          </div>

          {/* Project Counter & Manual Controls */}
          <div className="flex items-center space-x-6">
            <div className="font-mono text-xs tracking-widest text-[#A6A6A6]">
              <span className="text-xl font-display font-bold text-[#EDECE8]">
                {activeProject.num}
              </span>
              <span className="mx-1">/</span>
              <span>0{projects.length}</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={prevProject}
                data-cursor="PREV"
                aria-label="Previous project"
                className="w-9 h-9 md:w-10 md:h-10 rounded-full border border-[#262629] flex items-center justify-center hover:border-[#EDECE8] hover:bg-[#EDECE8] hover:text-[#0D0D0F] transition-all duration-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextProject}
                data-cursor="NEXT"
                aria-label="Next project"
                className="w-9 h-9 md:w-10 md:h-10 rounded-full border border-[#262629] flex items-center justify-center hover:border-[#EDECE8] hover:bg-[#EDECE8] hover:text-[#0D0D0F] transition-all duration-300 cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 3D Carousel Stage */}
        <div className="relative flex-1 w-full max-w-7xl mx-auto flex items-center justify-center perspective-2000 py-4 sm:py-6">
          <div className="relative w-full h-[320px] sm:h-[420px] md:h-[480px] lg:h-[520px] flex items-center justify-center preserve-3d">
            {projects.map((project, idx) => {
              const diff = idx - activeIndex;
              const isActive = diff === 0;

              // Calculate 3D transforms based on offset from active
              let translateX = diff * 540;
              let translateZ = Math.abs(diff) * -260;
              let rotateY = diff * -24;
              let opacity = 1 - Math.abs(diff) * 0.45;
              let scale = isActive ? 1 : 0.86;

              if (Math.abs(diff) > 2) {
                opacity = 0;
                translateX = diff > 0 ? 1200 : -1200;
              }

              return (
                <div
                  key={project.id}
                  onClick={() => setActiveIndex(idx)}
                  className={`absolute w-[88vw] max-w-[680px] lg:max-w-[800px] h-full rounded-2xl overflow-hidden transition-all duration-700 ease-out cursor-pointer group shadow-2xl ${
                    isActive ? 'z-30 pointer-events-auto' : 'z-10 pointer-events-auto'
                  }`}
                  style={{
                    transform: `translate3d(${translateX}px, 0px, ${translateZ}px) rotateY(${rotateY}deg) scale(${scale})`,
                    opacity: Math.max(0, opacity),
                  }}
                >
                  {/* Website Mockup Panel */}
                  <div className="relative w-full h-full bg-[#1A1A1D] rounded-2xl overflow-hidden border border-[#262629] flex flex-col">
                    {/* Minimal Browser Header Bar */}
                    <div className="h-9 bg-[#141416] border-b border-[#262629] px-4 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#262629]" />
                        <span className="w-2.5 h-2.5 rounded-full bg-[#262629]" />
                        <span className="w-2.5 h-2.5 rounded-full bg-[#262629]" />
                      </div>
                      <span className="text-[10px] font-mono text-[#A6A6A6] truncate max-w-[240px]">
                        {project.url.replace('https://', '')}
                      </span>
                      {project.isDemo && (
                        <span className="text-[9px] font-mono uppercase px-2 py-0.5 rounded bg-[#EDECE8]/10 text-[#EDECE8]">
                          Demo Site
                        </span>
                      )}
                    </div>

                    {/* Screenshot Preview */}
                    <div className="relative flex-1 w-full overflow-hidden bg-[#0D0D0F]">
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                        loading="lazy"
                      />
                      {/* Dark overlay for inactive cards */}
                      {!isActive && (
                        <div className="absolute inset-0 bg-[#0D0D0F]/65 transition-opacity duration-500" />
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Active Project Info Bar */}
        <div className="max-w-7xl mx-auto w-full pt-4 border-t border-[#262629] flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-3">
              <span className="text-xs font-mono text-[#A6A6A6] uppercase tracking-wider">
                {activeProject.category}
              </span>
              <span className="w-1 h-1 rounded-full bg-[#A6A6A6]" />
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest">
                Active Project
              </span>
            </div>
            <h3 className="font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight text-[#EDECE8] mt-1">
              {activeProject.title}
            </h3>
            <p className="text-xs md:text-sm text-[#A6A6A6] max-w-xl mt-1 line-clamp-1">
              {activeProject.description}
            </p>
          </div>

          {/* Working "View Live Website" CTA */}
          <a
            href={activeProject.url}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor="OPEN"
            className="group inline-flex items-center justify-center space-x-3 px-6 py-3.5 rounded-full bg-[#EDECE8] text-[#0D0D0F] font-mono text-xs uppercase tracking-widest font-bold transition-all duration-300 hover:bg-white hover:scale-105 shadow-lg shrink-0 cursor-pointer"
          >
            <span>View Live Website</span>
            <ExternalLink className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>
      </div>
    </section>
  );
}
