import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

interface PreloaderProps {
  onComplete: () => void;
}

export default function Preloader({ onComplete }: PreloaderProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const textAkRef = useRef<HTMLDivElement>(null);
  const textFullRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLSpanElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        onComplete: () => {
          gsap.to(containerRef.current, {
            yPercent: -100,
            duration: 0.9,
            ease: 'expo.inOut',
            onComplete: onComplete,
          });
        },
      });

      // Progress number animation
      const countObj = { val: 0 };
      gsap.to(countObj, {
        val: 100,
        duration: 1.4,
        ease: 'power2.out',
        onUpdate: () => {
          const val = Math.floor(countObj.val);
          setProgress(val);
        },
      });

      // Entrance: A K.
      tl.fromTo(
        textAkRef.current,
        { opacity: 0, y: 30, letterSpacing: '0.2em', filter: 'blur(10px)' },
        { opacity: 1, y: 0, letterSpacing: '-0.04em', filter: 'blur(0px)', duration: 0.6, ease: 'power3.out' }
      )
        // Transition A K. out
        .to(textAkRef.current, {
          opacity: 0,
          y: -20,
          filter: 'blur(8px)',
          duration: 0.35,
          delay: 0.3,
          ease: 'power2.in',
        })
        // Reveal ABHIGYAN KALITA
        .fromTo(
          textFullRef.current,
          { opacity: 0, scale: 0.92, letterSpacing: '0.4em', filter: 'blur(12px)' },
          {
            opacity: 1,
            scale: 1,
            letterSpacing: '0.08em',
            filter: 'blur(0px)',
            duration: 0.65,
            ease: 'power4.out',
          },
          '-=0.1'
        )
        // Hold briefly for cinematic punch
        .to(textFullRef.current, {
          y: -40,
          opacity: 0,
          filter: 'blur(10px)',
          duration: 0.4,
          delay: 0.3,
          ease: 'power3.in',
        });
    }, containerRef);

    return () => ctx.revert();
  }, [onComplete]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[99999] flex flex-col items-center justify-between bg-[#0D0D0F] px-8 py-10 text-[#EDECE8] select-none"
    >
      {/* Top Bar Indicator */}
      <div className="w-full flex items-center justify-between text-xs tracking-widest text-[#A6A6A6] font-mono uppercase">
        <span>Abhigyan Kalita</span>
        <span>Portfolio 2026</span>
      </div>

      {/* Center Cinematic Typography */}
      <div className="relative flex items-center justify-center text-center">
        {/* Step 1: A K. */}
        <div
          ref={textAkRef}
          className="text-6xl md:text-8xl lg:text-9xl font-black font-display tracking-tighter text-[#EDECE8]"
        >
          A K.
        </div>

        {/* Step 2: ABHIGYAN KALITA */}
        <div
          ref={textFullRef}
          className="absolute inset-0 flex items-center justify-center opacity-0 whitespace-nowrap text-3xl md:text-5xl lg:text-7xl font-extrabold font-display tracking-tight text-[#EDECE8]"
        >
          ABHIGYAN KALITA
        </div>
      </div>

      {/* Bottom Progress Counter */}
      <div className="w-full flex items-end justify-between text-xs font-mono text-[#A6A6A6]">
        <span className="tracking-widest uppercase">Initializing Studio</span>
        <div className="flex items-baseline space-x-1">
          <span ref={progressRef} className="text-2xl md:text-3xl font-bold font-display text-[#EDECE8]">
            {progress < 10 ? `0${progress}` : progress}
          </span>
          <span className="text-xs text-[#A6A6A6]">%</span>
        </div>
      </div>
    </div>
  );
}
