import { useState, useEffect } from 'react';
import { ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  onContactClick: () => void;
}

export default function Navbar({ onContactClick }: NavbarProps) {
  const [istTime, setIstTime] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  const [isHero, setIsHero] = useState(true);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      };
      setIstTime(new Intl.DateTimeFormat('en-US', options).format(now));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    const onScroll = () => {
      const scrollY = window.scrollY;
      setIsScrolled(scrollY > 30);
      setIsHero(scrollY < window.innerHeight * 0.82);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    return () => {
      clearInterval(interval);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        !isHero
          ? 'py-4 bg-[#0D0D0F]/90 backdrop-blur-md border-b border-[#262629] text-[#EDECE8]'
          : isScrolled
          ? 'py-4 bg-[#EDECE8]/90 backdrop-blur-md border-b border-[#0D0D0F]/10 text-[#0D0D0F]'
          : 'py-6 bg-transparent text-[#0D0D0F]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Brand Monogram */}
        <a
          href="#hero"
          onClick={(e) => {
            e.preventDefault();
            scrollTo('hero');
          }}
          className="group flex items-center space-x-3 cursor-pointer"
        >
          <span className="font-display font-black text-lg md:text-xl tracking-tighter uppercase transition-transform group-hover:scale-105 duration-300">
            Abhigyan Kalita
          </span>
          <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        </a>

        {/* Live IST indicator */}
        <div className="hidden lg:flex items-center space-x-2 text-xs font-mono tracking-wider opacity-75">
          <span>INDIA</span>
          <span>•</span>
          <span className="tabular-nums font-semibold">{istTime || 'IST'}</span>
        </div>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center space-x-7 text-xs font-mono tracking-widest uppercase">
          <button
            onClick={() => scrollTo('work')}
            className="hover:opacity-50 transition-opacity cursor-pointer"
          >
            01 / Work
          </button>
          <button
            onClick={() => scrollTo('process')}
            className="hover:opacity-50 transition-opacity cursor-pointer"
          >
            02 / Process
          </button>
          <button
            onClick={() => scrollTo('services')}
            className="hover:opacity-50 transition-opacity cursor-pointer"
          >
            03 / Services
          </button>
          <button
            onClick={() => scrollTo('build')}
            className="hover:opacity-50 transition-opacity cursor-pointer"
          >
            04 / Build
          </button>
        </nav>

        {/* CTA Contact Button */}
        <button
          onClick={onContactClick}
          data-cursor="CONNECT"
          className={`group relative inline-flex items-center space-x-2 px-5 py-2.5 rounded-full border text-xs font-mono tracking-widest uppercase overflow-hidden transition-all duration-300 cursor-pointer ${
            isHero
              ? 'border-[#0D0D0F] text-[#0D0D0F] hover:bg-[#0D0D0F] hover:text-[#EDECE8]'
              : 'border-[#EDECE8] text-[#EDECE8] hover:bg-[#EDECE8] hover:text-[#0D0D0F]'
          }`}
        >
          <span className="relative z-10 font-bold">Let's Talk</span>
          <ArrowUpRight className="relative z-10 w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </button>
      </div>
    </header>
  );
}
