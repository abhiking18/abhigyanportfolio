import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function CreativeIntroSection() {
  const containerRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);
  const ghostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    const heading = headingRef.current;
    const text = textRef.current;
    const ghost = ghostRef.current;

    if (!container || !heading || !text) return;

    const ctx = gsap.context(() => {
      // Reveal headline with mask and blur
      gsap.fromTo(
        heading.querySelectorAll('.line-reveal'),
        { yPercent: 100, opacity: 0, filter: 'blur(8px)' },
        {
          yPercent: 0,
          opacity: 1,
          filter: 'blur(0px)',
          duration: 1.1,
          stagger: 0.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: container,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Reveal description
      gsap.fromTo(
        text,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: container,
            start: 'top 55%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Ghost background text horizontal drift
      if (ghost) {
        gsap.to(ghost, {
          xPercent: -20,
          ease: 'none',
          scrollTrigger: {
            trigger: container,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true,
          },
        });
      }
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="about"
      ref={containerRef}
      className="relative w-full min-h-[80vh] bg-[#0D0D0F] text-[#EDECE8] flex flex-col justify-center overflow-hidden py-24 px-6 md:px-12 select-none"
    >
      {/* Background Ghost Watermark */}
      <div
        ref={ghostRef}
        className="absolute top-1/2 -translate-y-1/2 left-0 whitespace-nowrap text-[22vw] font-black font-display text-white/[0.025] pointer-events-none select-none tracking-tighter"
      >
        CREATIVE TECHNOLOGIST • DESIGN • CODE
      </div>

      <div className="relative z-10 max-w-6xl mx-auto w-full">
        {/* Minimal Subhead */}
        <div className="flex items-center space-x-3 mb-6 text-[#A6A6A6] font-mono text-xs uppercase tracking-widest">
          <span className="w-6 h-[1px] bg-[#A6A6A6]" />
          <span>Philosophy</span>
        </div>

        {/* Oversized Animated Typography */}
        <h2
          ref={headingRef}
          className="font-display font-black text-6xl sm:text-7xl md:text-8xl lg:text-9xl tracking-tighter uppercase leading-[0.88] mb-8"
        >
          <div className="overflow-hidden">
            <span className="line-reveal block">CREATIVE</span>
          </div>
          <div className="overflow-hidden">
            <span className="line-reveal block text-[#A6A6A6]">TECHNOLOGIST.</span>
          </div>
        </h2>

        {/* Minimal 1-liner Description */}
        <div className="max-w-2xl border-l-2 border-[#262629] pl-6 md:pl-8">
          <p
            ref={textRef}
            className="text-lg sm:text-2xl md:text-3xl font-light text-[#EDECE8] leading-snug tracking-tight font-editorial"
          >
            I build modern digital experiences through design, technology and creativity.
          </p>
        </div>
      </div>
    </section>
  );
}
