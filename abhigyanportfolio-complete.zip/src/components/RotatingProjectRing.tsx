import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { projects } from './SelectedProjects3D';

gsap.registerPlugin(ScrollTrigger);

// 6 panels for smooth continuous 360-degree cylindrical orbit
const ringItems = [
  projects[0],
  projects[1],
  projects[2],
  projects[3],
  projects[0],
  projects[1],
];

export default function RotatingProjectRing() {
  const containerRef = useRef<HTMLElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const startX = useRef(0);
  const currentRotation = useRef(0);

  useEffect(() => {
    const container = containerRef.current;
    const ring = ringRef.current;
    if (!container || !ring) return;

    const ctx = gsap.context(() => {
      // Rotate the 3D ring continuously based on scroll progress
      gsap.to(ring, {
        rotateY: 360,
        ease: 'none',
        scrollTrigger: {
          trigger: container,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.5,
          onUpdate: (self) => {
            currentRotation.current = self.progress * 360;
          },
        },
      });
    }, container);

    return () => ctx.revert();
  }, []);

  // Mouse drag to interactively rotate ring
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    startX.current = e.clientX;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current || !ringRef.current) return;
    const deltaX = e.clientX - startX.current;
    startX.current = e.clientX;
    currentRotation.current += deltaX * 0.4;
    gsap.to(ringRef.current, {
      rotateY: currentRotation.current,
      duration: 0.3,
      ease: 'power1.out',
    });
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const count = ringItems.length;
  const radius = 520; // 3D distance from center

  return (
    <section
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative w-full min-h-[85vh] bg-[#0D0D0F] text-[#EDECE8] flex items-center justify-center overflow-hidden py-20 cursor-grab active:cursor-grabbing select-none"
    >
      {/* Background Subtle Atmosphere Glow */}
      <div className="absolute w-[600px] h-[600px] rounded-full bg-white/[0.02] filter blur-[120px] pointer-events-none" />

      {/* 3D Cylindrical Ring Stage (No blocking center text) */}
      <div className="relative w-full h-[500px] flex items-center justify-center perspective-2000 pointer-events-none">
        <div
          ref={ringRef}
          className="relative w-full h-full flex items-center justify-center preserve-3d will-change-transform"
        >
          {ringItems.map((item, idx) => {
            const angle = (idx / count) * 360;
            return (
              <div
                key={idx}
                className="absolute w-[280px] sm:w-[340px] md:w-[380px] h-[200px] sm:h-[240px] md:h-[260px] rounded-xl overflow-hidden shadow-2xl border border-[#262629] bg-[#141416] transition-transform duration-300 pointer-events-auto"
                style={{
                  transform: `rotateY(${angle}deg) translateZ(${radius}px)`,
                }}
              >
                {/* Screenshot inside panel */}
                <div className="relative w-full h-full group overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  {/* Subtle bottom gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0F] via-transparent to-transparent opacity-80" />

                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                    <div>
                      <div className="text-[9px] font-mono uppercase text-[#A6A6A6]">
                        {item.category}
                      </div>
                      <div className="text-xs font-display font-bold text-[#EDECE8] truncate max-w-[200px]">
                        {item.title}
                      </div>
                    </div>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-7 h-7 rounded-full bg-[#EDECE8] text-[#0D0D0F] flex items-center justify-center text-[10px] font-bold hover:scale-110 transition-transform"
                    >
                      ↗
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
