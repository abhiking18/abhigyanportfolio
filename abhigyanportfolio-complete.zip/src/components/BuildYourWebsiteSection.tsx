import { useState } from 'react';
import { Send, MessageSquare, Sparkles, Check } from 'lucide-react';

const projectTypes = [
  'Business Website',
  'Creative Portfolio',
  'Landing Page',
  'E-Commerce Store',
  'Website Redesign',
  'Custom 3D / WebGL',
];

const featureOptions = [
  'Cinematic Animations',
  'Ultra-Fast Loading',
  'High Conversion',
  'SEO Optimized',
  'Mobile-First',
  'CMS / Easy Updates',
];

const timelines = ['< 2 Weeks', '2 - 4 Weeks', '1+ Month', 'Flexible'];

export default function BuildYourWebsiteSection() {
  const [selectedType, setSelectedType] = useState('Business Website');
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    'Cinematic Animations',
    'Ultra-Fast Loading',
  ]);
  const [selectedTimeline, setSelectedTimeline] = useState('2 - 4 Weeks');
  const [clientName, setClientName] = useState('');
  const [clientContact, setClientContact] = useState('');
  const [ideaText, setIdeaText] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const phoneNumber = '916003639279';
  const emailAddress = 'abhigyankalita.official@gmail.com';

  const toggleFeature = (feature: string) => {
    setSelectedFeatures((prev) =>
      prev.includes(feature)
        ? prev.filter((f) => f !== feature)
        : [...prev, feature]
    );
  };

  const generateBrief = () => {
    return (
      `*NEW WEBSITE PROJECT BRIEF*\n\n` +
      `• *Client Name:* ${clientName || 'Not specified'}\n` +
      `• *Contact:* ${clientContact || 'Not specified'}\n` +
      `• *Website Type:* ${selectedType}\n` +
      `• *Features Needed:* ${selectedFeatures.join(', ') || 'Custom'}\n` +
      `• *Timeline:* ${selectedTimeline}\n\n` +
      `• *Project Idea / Vision:*\n${ideaText || 'Let discuss on call.'}`
    );
  };

  const handleSendWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    const brief = generateBrief();
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(brief)}`;
    window.open(url, '_blank');
    setSubmitted(true);
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Website Idea from ${clientName || 'Client'} [${selectedType}]`);
    const brief = generateBrief();
    const url = `mailto:${emailAddress}?subject=${subject}&body=${encodeURIComponent(brief)}`;
    window.open(url, '_blank');
    setSubmitted(true);
  };

  return (
    <section
      id="build"
      className="relative w-full bg-[#0D0D0F] text-[#EDECE8] py-28 px-6 md:px-12 select-none border-t border-[#262629]"
    >
      <div className="max-w-5xl mx-auto w-full">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-[#262629] pb-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 text-[#A6A6A6] font-mono text-xs uppercase tracking-widest mb-3">
              <Sparkles className="w-3.5 h-3.5 text-[#EDECE8]" />
              <span>Interactive Project Configurator</span>
            </div>
            <h2 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tighter uppercase text-[#EDECE8] leading-[0.88]">
              BUILD YOUR<br />
              <span className="text-[#A6A6A6]">WEBSITE.</span>
            </h2>
          </div>
          <p className="text-xs sm:text-sm font-mono text-[#A6A6A6] max-w-xs mt-4 md:mt-0">
            Tell me about your idea, pick your preferences, and let's craft something exceptional.
          </p>
        </div>

        {submitted ? (
          <div className="p-12 rounded-2xl border border-[#262629] bg-[#141416] text-center my-8">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center mb-4">
              <Check className="w-7 h-7" />
            </div>
            <h3 className="text-2xl sm:text-3xl font-display font-black uppercase text-[#EDECE8] tracking-tight">
              Website Idea Prepared!
            </h3>
            <p className="text-xs sm:text-sm font-mono text-[#A6A6A6] mt-2 max-w-md mx-auto">
              Your customized project brief has been formatted and opened. I will review your idea and get back to you promptly.
            </p>
            <button
              onClick={() => setSubmitted(false)}
              className="mt-6 text-xs font-mono uppercase tracking-widest text-[#EDECE8] underline underline-offset-4 cursor-pointer"
            >
              Configure Another Idea
            </button>
          </div>
        ) : (
          <form className="space-y-10">
            {/* Step 1: Website Type */}
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#A6A6A6] block mb-3">
                01 / What type of website do you need?
              </span>
              <div className="flex flex-wrap gap-2.5">
                {projectTypes.map((type) => {
                  const active = selectedType === type;
                  return (
                    <button
                      type="button"
                      key={type}
                      onClick={() => setSelectedType(type)}
                      className={`px-4 py-2.5 rounded-full text-xs font-mono tracking-wider transition-all duration-300 cursor-pointer ${
                        active
                          ? 'bg-[#EDECE8] text-[#0D0D0F] font-bold shadow-md'
                          : 'bg-[#141416] text-[#A6A6A6] border border-[#262629] hover:border-[#EDECE8]/60 hover:text-[#EDECE8]'
                      }`}
                    >
                      {type}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Key Requirements */}
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#A6A6A6] block mb-3">
                02 / Key Priorities (Select all that apply)
              </span>
              <div className="flex flex-wrap gap-2.5">
                {featureOptions.map((feat) => {
                  const active = selectedFeatures.includes(feat);
                  return (
                    <button
                      type="button"
                      key={feat}
                      onClick={() => toggleFeature(feat)}
                      className={`px-4 py-2 rounded-full text-xs font-mono tracking-wider transition-all duration-300 cursor-pointer ${
                        active
                          ? 'bg-[#EDECE8] text-[#0D0D0F] font-bold'
                          : 'bg-[#141416] text-[#A6A6A6] border border-[#262629] hover:border-[#EDECE8]/40 hover:text-[#EDECE8]'
                      }`}
                    >
                      {active ? '✓ ' : '+ '}
                      {feat}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Timeline */}
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#A6A6A6] block mb-3">
                03 / Target Launch Timeline
              </span>
              <div className="flex flex-wrap gap-2.5">
                {timelines.map((time) => {
                  const active = selectedTimeline === time;
                  return (
                    <button
                      type="button"
                      key={time}
                      onClick={() => setSelectedTimeline(time)}
                      className={`px-4 py-2 rounded-full text-xs font-mono tracking-wider transition-all duration-300 cursor-pointer ${
                        active
                          ? 'bg-[#EDECE8] text-[#0D0D0F] font-bold'
                          : 'bg-[#141416] text-[#A6A6A6] border border-[#262629] hover:border-[#EDECE8]/40 hover:text-[#EDECE8]'
                      }`}
                    >
                      {time}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 4: Describe Your Idea & Contact */}
            <div className="space-y-4 pt-4 border-t border-[#262629]">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#A6A6A6] block mb-1">
                04 / Your Vision &amp; Contact
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <input
                    type="text"
                    required
                    placeholder="Your Name / Company"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-[#141416] border border-[#262629] rounded-xl px-4 py-3 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <input
                    type="text"
                    required
                    placeholder="Your Phone / WhatsApp or Email"
                    value={clientContact}
                    onChange={(e) => setClientContact(e.target.value)}
                    className="w-full bg-[#141416] border border-[#262629] rounded-xl px-4 py-3 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <textarea
                  rows={4}
                  required
                  placeholder="Tell me about your idea: What is your business, what vibe do you love, any reference websites, or special features you have in mind?"
                  value={ideaText}
                  onChange={(e) => setIdeaText(e.target.value)}
                  className="w-full bg-[#141416] border border-[#262629] rounded-xl p-4 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors resize-none leading-relaxed"
                />
              </div>

              {/* Action Buttons: WhatsApp or Direct Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <button
                  type="button"
                  onClick={handleSendWhatsApp}
                  data-cursor="WHATSAPP"
                  className="w-full py-3.5 px-6 rounded-full bg-[#EDECE8] text-[#0D0D0F] font-mono text-xs uppercase tracking-widest font-bold flex items-center justify-center space-x-2 hover:bg-white transition-all cursor-pointer shadow-lg"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send Idea via WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendEmail}
                  data-cursor="EMAIL"
                  className="w-full py-3.5 px-6 rounded-full border border-[#262629] bg-[#141416] text-[#EDECE8] font-mono text-xs uppercase tracking-widest font-bold flex items-center justify-center space-x-2 hover:border-[#EDECE8] hover:bg-[#1A1A1D] transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Idea via Email</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </section>
  );
}
