import { useState } from 'react';
import { Plus, Minus, ArrowRight } from 'lucide-react';

interface ServiceItem {
  number: string;
  title: string;
  summary: string;
}

const servicesList: ServiceItem[] = [
  {
    number: '01',
    title: 'Website Development',
    summary: 'High-performance bespoke web applications with fluid motion design and clean code.',
  },
  {
    number: '02',
    title: 'UI/UX Design',
    summary: 'Editorial user interfaces crafted with deliberate typography and spatial hierarchy.',
  },
  {
    number: '03',
    title: 'Business Websites',
    summary: 'Commanding digital flagships that establish authority and convert visitors.',
  },
  {
    number: '04',
    title: 'Website Redesign',
    summary: 'Modernizing legacy websites into contemporary, award-worthy experiences.',
  },
  {
    number: '05',
    title: 'Landing Pages',
    summary: 'High-impact campaign pages with cinematic storytelling and focused conversion.',
  },
];

export default function ServicesSection({ onContactClick }: { onContactClick: () => void }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleService = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section
      id="services"
      className="relative w-full bg-[#0D0D0F] text-[#EDECE8] py-24 px-6 md:px-12 select-none border-t border-[#262629]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-end justify-between border-b border-[#262629] pb-6 mb-12">
          <h2 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tighter uppercase text-[#EDECE8] leading-[0.9]">
            WHAT I CAN DO FOR YOU.
          </h2>
          <span className="text-xs font-mono uppercase tracking-widest text-[#A6A6A6] hidden sm:block">
            05 Services
          </span>
        </div>

        {/* Accordion Rows */}
        <div className="divide-y divide-[#262629] border-b border-[#262629]">
          {servicesList.map((service, idx) => {
            const isOpen = openIndex === idx;

            return (
              <div
                key={service.number}
                className="group transition-colors duration-300"
              >
                {/* Header Row */}
                <button
                  onClick={() => toggleService(idx)}
                  className="w-full py-6 md:py-9 flex items-center justify-between text-left cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <div className="flex items-baseline space-x-6 md:space-x-10">
                    <span className="font-mono text-sm text-[#A6A6A6] tracking-widest">
                      {service.number}
                    </span>
                    <h3 className="font-display font-black text-2xl sm:text-3xl md:text-5xl lg:text-6xl tracking-tighter uppercase text-[#EDECE8] group-hover:text-white transition-colors">
                      {service.title}
                    </h3>
                  </div>

                  <div className="w-9 h-9 md:w-11 md:h-11 rounded-full border border-[#262629] flex items-center justify-center text-[#EDECE8] group-hover:border-[#EDECE8] transition-all duration-300 shrink-0 ml-4">
                    {isOpen ? (
                      <Minus className="w-4 h-4 transition-transform duration-300" />
                    ) : (
                      <Plus className="w-4 h-4 transition-transform duration-300 group-hover:rotate-90" />
                    )}
                  </div>
                </button>

                {/* Expanded Details */}
                <div
                  className={`grid transition-all duration-400 ease-in-out ${
                    isOpen
                      ? 'grid-rows-[1fr] opacity-100 pb-8'
                      : 'grid-rows-[0fr] opacity-0 pb-0'
                  }`}
                >
                  <div className="overflow-hidden pl-10 md:pl-16 max-w-3xl">
                    <p className="text-base md:text-lg text-[#A6A6A6] font-light leading-relaxed mb-4 font-editorial">
                      {service.summary}
                    </p>

                    <button
                      onClick={onContactClick}
                      className="inline-flex items-center space-x-2 text-xs font-mono uppercase tracking-widest text-[#EDECE8] hover:text-white font-bold cursor-pointer underline underline-offset-4"
                    >
                      <span>Inquire Now</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
