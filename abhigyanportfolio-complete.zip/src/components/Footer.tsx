import { ArrowUp } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#0D0D0F] text-[#A6A6A6] border-t border-[#262629] py-12 px-6 md:px-12 select-none">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs font-mono">
        {/* Left */}
        <div className="flex items-center space-x-3">
          <span className="font-display font-bold text-[#EDECE8] tracking-wider uppercase">
            Abhigyan Kalita
          </span>
          <span>•</span>
          <span>Creative Web Developer &amp; Designer</span>
        </div>

        {/* Center */}
        <div className="text-center text-[#A6A6A6]/60">
          BASED IN INDIA — AVAILABLE WORLDWIDE
        </div>

        {/* Right / Back to Top */}
        <div className="flex items-center space-x-6">
          <span>© 2026 ALL RIGHTS RESERVED</span>
          <button
            onClick={scrollToTop}
            data-cursor="TOP"
            aria-label="Scroll to top"
            className="w-8 h-8 rounded-full border border-[#262629] flex items-center justify-center hover:border-[#EDECE8] hover:text-[#EDECE8] transition-colors cursor-pointer"
          >
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
}
