import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const countries = [
  'INDIA',
  'USA',
  'UK',
  'CANADA',
  'SWITZERLAND',
  'SPAIN',
  'UAE',
];

export default function ExperiencePresenceSection() {
  const containerRef = useRef<HTMLElement>(null);
  const marqueeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const marquee = marqueeRef.current;
    if (!marquee) return;

    const ctx = gsap.context(() => {
      gsap.to(marquee, {
        x: '-30%',
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.2,
        },
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={containerRef}
      className="relative w-full bg-[#0D0D0F] text-[#EDECE8] border-y border-[#262629] py-20 overflow-hidden select-none"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 mb-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-baseline">
          {/* Left Column: Heading */}
          <div className="lg:col-span-8">
            <h3 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tighter uppercase leading-[0.9]">
              BASED IN INDIA.<br />
              <span className="text-[#A6A6A6]">BUILDING FOR THE WORLD.</span>
            </h3>
          </div>

          {/* Right Column: Experience */}
          <div className="lg:col-span-4 lg:text-right border-l lg:border-l-0 lg:border-r border-[#262629] pl-6 lg:pl-0 lg:pr-8">
            <div className="text-5xl sm:text-6xl md:text-7xl font-display font-black tracking-tighter text-[#EDECE8]">
              3+ YEARS
            </div>
            <div className="text-xs sm:text-sm font-mono tracking-widest uppercase text-[#A6A6A6] mt-1">
              OF EXPERIENCE
            </div>
          </div>
        </div>
      </div>

      {/* Large Animated Marquee */}
      <div className="relative w-full overflow-hidden border-t border-[#262629] py-6 bg-[#0D0D0F]">
        <div
          ref={marqueeRef}
          className="flex whitespace-nowrap will-change-transform"
        >
          {[...countries, ...countries, ...countries].map((country, idx) => (
            <div
              key={idx}
              className="inline-flex items-center space-x-8 md:space-x-12 px-4 md:px-6"
            >
              <span className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tighter text-transparent stroke-text hover:text-[#EDECE8] transition-colors duration-500 cursor-default">
                {country}
              </span>
              <span className="text-2xl sm:text-3xl font-light text-[#262629]">/</span>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        .stroke-text {
          -webkit-text-stroke: 1px #EDECE8;
          color: transparent;
        }
        .stroke-text:hover {
          color: #EDECE8;
          -webkit-text-stroke: 1px transparent;
        }
      `}</style>
    </section>
  );
}
