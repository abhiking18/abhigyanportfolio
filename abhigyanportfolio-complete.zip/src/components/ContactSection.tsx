import { useState } from 'react';
import { Mail, MessageSquare, Phone, Copy, Check, Send, ArrowUpRight } from 'lucide-react';

const InstagramIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

export default function ContactSection() {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: 'Website Development',
    message: '',
  });

  const contactEmail = 'abhigyankalita.official@gmail.com';
  const phoneNumber = '+91 60036 39279';
  const phoneRaw = '916003639279';
  const instagramHandle = 'builtsbyabhi';

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(contactEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText('+916003639279');
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Project: ${formData.service} from ${formData.name}`);
    const body = encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\nService: ${formData.service}\n\n${formData.message}`
    );
    window.open(`mailto:${contactEmail}?subject=${subject}&body=${body}`, '_blank');
    setFormSubmitted(true);
  };

  return (
    <section
      id="contact"
      className="relative w-full min-h-screen bg-[#0D0D0F] text-[#EDECE8] py-24 px-6 md:px-12 flex flex-col justify-between select-none border-t border-[#262629]"
    >
      <div className="max-w-5xl mx-auto w-full flex-1 flex flex-col justify-center">
        {/* Massive Centred Typography */}
        <div className="text-center mb-8">
          <h2 className="font-display font-black text-6xl sm:text-8xl md:text-9xl lg:text-[11vw] tracking-tighter uppercase leading-[0.82] text-[#EDECE8]">
            LET'S TALK.
          </h2>
          <p className="text-base sm:text-xl font-light text-[#A6A6A6] mt-3 font-editorial">
            Have something in mind? Let's build it.
          </p>
        </div>

        {/* Direct Contact Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 max-w-4xl mx-auto w-full my-8">
          {/* Phone / Call */}
          <div className="p-4 rounded-xl border border-[#262629] bg-[#141416] flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#A6A6A6] mb-3">
              <Phone className="w-4 h-4" />
              <button
                onClick={handleCopyPhone}
                className="text-[10px] font-mono text-[#A6A6A6] hover:text-[#EDECE8] cursor-pointer"
              >
                {copiedPhone ? 'COPIED' : 'COPY'}
              </button>
            </div>
            <div>
              <div className="text-[9px] font-mono uppercase text-[#A6A6A6]">Call / Phone</div>
              <a
                href={`tel:+${phoneRaw}`}
                className="text-xs sm:text-sm font-mono font-medium text-[#EDECE8] hover:underline mt-0.5 block"
              >
                {phoneNumber}
              </a>
            </div>
          </div>

          {/* WhatsApp */}
          <a
            href={`https://wa.me/${phoneRaw}`}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor="CHAT"
            className="group p-4 rounded-xl border border-[#262629] bg-[#141416] hover:border-[#EDECE8]/60 transition-all duration-300 flex flex-col justify-between cursor-pointer"
          >
            <div className="flex items-center justify-between text-[#A6A6A6] group-hover:text-[#EDECE8] mb-3">
              <MessageSquare className="w-4 h-4" />
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
            <div>
              <div className="text-[9px] font-mono uppercase text-[#A6A6A6]">WhatsApp</div>
              <div className="text-xs sm:text-sm font-mono font-medium text-[#EDECE8] mt-0.5">
                {phoneNumber}
              </div>
            </div>
          </a>

          {/* Instagram: @builtsbyabhi */}
          <a
            href={`https://instagram.com/${instagramHandle}`}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor="INSTA"
            className="group p-4 rounded-xl border border-[#262629] bg-[#141416] hover:border-[#EDECE8]/60 transition-all duration-300 flex flex-col justify-between cursor-pointer"
          >
            <div className="flex items-center justify-between text-[#A6A6A6] group-hover:text-[#EDECE8] mb-3">
              <InstagramIcon className="w-4 h-4" />
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
            <div>
              <div className="text-[9px] font-mono uppercase text-[#A6A6A6]">Instagram</div>
              <div className="text-xs sm:text-sm font-mono font-medium text-[#EDECE8] mt-0.5">
                @{instagramHandle}
              </div>
            </div>
          </a>

          {/* Direct Email */}
          <button
            onClick={handleCopyEmail}
            data-cursor="EMAIL"
            className="group p-4 rounded-xl border border-[#262629] bg-[#141416] hover:border-[#EDECE8]/60 transition-all duration-300 text-left cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center justify-between text-[#A6A6A6] group-hover:text-[#EDECE8] mb-3">
              <Mail className="w-4 h-4" />
              {copiedEmail ? (
                <span className="text-[10px] font-mono text-emerald-400 flex items-center space-x-1">
                  <Check className="w-3 h-3" />
                  <span>COPIED</span>
                </span>
              ) : (
                <Copy className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100" />
              )}
            </div>
            <div>
              <div className="text-[9px] font-mono uppercase text-[#A6A6A6]">Direct Email</div>
              <div className="text-xs sm:text-sm font-mono font-medium text-[#EDECE8] truncate mt-0.5">
                {contactEmail}
              </div>
            </div>
          </button>
        </div>

        {/* Minimal Project Enquiry Form */}
        <div className="max-w-lg mx-auto w-full bg-[#141416] border border-[#262629] rounded-2xl p-6 sm:p-7">
          <div className="text-xs font-mono uppercase tracking-widest text-[#A6A6A6] mb-5">
            Quick Inquiry
          </div>

          {formSubmitted ? (
            <div className="text-center py-6">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center mb-3">
                <Check className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-display font-bold text-[#EDECE8]">Inquiry Generated</h4>
              <p className="text-xs font-mono text-[#A6A6A6] mt-1.5">
                Email draft prepared with your brief.
              </p>
              <button
                onClick={() => setFormSubmitted(false)}
                className="mt-4 text-xs font-mono uppercase text-[#EDECE8] underline underline-offset-4 cursor-pointer"
              >
                Send Another
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Your Name"
                    className="w-full bg-[#0D0D0F] border border-[#262629] rounded-lg px-3 py-2 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="Your Email"
                    className="w-full bg-[#0D0D0F] border border-[#262629] rounded-lg px-3 py-2 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <select
                  value={formData.service}
                  onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  className="w-full bg-[#0D0D0F] border border-[#262629] rounded-lg px-3 py-2 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors"
                >
                  <option value="Website Development">Website Development</option>
                  <option value="UI/UX Design">UI/UX Design</option>
                  <option value="Business Websites">Business Websites</option>
                  <option value="Website Redesign">Website Redesign</option>
                  <option value="Landing Pages">Landing Pages</option>
                </select>
              </div>

              <div>
                <textarea
                  rows={2}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell me about your project..."
                  className="w-full bg-[#0D0D0F] border border-[#262629] rounded-lg px-3 py-2 text-xs font-mono text-[#EDECE8] focus:border-[#EDECE8] focus:outline-none transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                data-cursor="SEND"
                className="w-full py-3 rounded-lg bg-[#EDECE8] text-[#0D0D0F] font-mono text-xs uppercase tracking-widest font-bold flex items-center justify-center space-x-2 hover:bg-white transition-all cursor-pointer shadow-lg"
              >
                <span>Send Brief</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
