import { useState, useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface Stage {
  number: string;
  name: string;
  description: string;
}

const stages: Stage[] = [
  {
    number: '01',
    name: 'Discovery',
    description: 'Deconstructing brand goals, audience intent, and creative direction.',
  },
  {
    number: '02',
    name: 'UI/UX Design',
    description: 'Sculpting high-contrast layouts and cinematic motion prototypes.',
  },
  {
    number: '03',
    name: 'Development',
    description: 'Engineering resilient React & GSAP scroll orchestrations.',
  },
  {
    number: '04',
    name: 'Testing & Review',
    description: 'Auditing 60fps frame rates and cross-device responsiveness.',
  },
  {
    number: '05',
    name: 'Launch',
    description: 'Production edge deployment and celebratory go-live delivery.',
  },
];

export default function DevelopmentProcessSection() {
  const containerRef = useRef<HTMLElement>(null);
  const [activeStage, setActiveStage] = useState(0);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const ctx = gsap.context(() => {
      const cards = container.querySelectorAll('.stage-card');
      cards.forEach((card, i) => {
        ScrollTrigger.create({
          trigger: card,
          start: 'top 65%',
          end: 'bottom 65%',
          onEnter: () => setActiveStage(i),
          onEnterBack: () => setActiveStage(i),
        });
      });
    }, container);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="process"
      ref={containerRef}
      className="relative w-full bg-[#EDECE8] text-[#0D0D0F] py-24 px-6 md:px-12 select-none"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex items-end justify-between border-b border-[#0D0D0F]/15 pb-6 mb-16">
          <h2 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tighter uppercase text-[#0D0D0F] leading-[0.88]">
            THE WAY I WORK.
          </h2>
          <span className="text-xs font-mono uppercase tracking-widest text-[#262629] hidden sm:block">
            05 Stages
          </span>
        </div>

        {/* 5 Stages List */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Fixed Stage Indicator on Desktop */}
          <div className="hidden lg:block lg:col-span-4 sticky top-36 h-fit">
            <div className="border-l-2 border-[#0D0D0F] pl-6 py-2">
              <div className="text-6xl font-display font-black tracking-tighter text-[#0D0D0F]">
                {stages[activeStage].number}
              </div>
              <div className="text-2xl font-display font-bold uppercase tracking-tight text-[#0D0D0F] mt-1">
                {stages[activeStage].name}
              </div>
            </div>

            <div className="mt-8 space-y-1.5 font-mono text-xs tracking-wider">
              {stages.map((stg, i) => (
                <button
                  key={stg.number}
                  onClick={() => {
                    const el = document.getElementById(`stage-${stg.number}`);
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`block w-full text-left py-1.5 px-3 rounded transition-all cursor-pointer ${
                    activeStage === i
                      ? 'bg-[#0D0D0F] text-[#EDECE8] font-bold'
                      : 'text-[#262629]/70 hover:text-[#0D0D0F]'
                  }`}
                >
                  {stg.number} — {stg.name}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Stages Stream */}
          <div className="lg:col-span-8 space-y-8">
            {stages.map((stage) => (
              <div
                key={stage.number}
                id={`stage-${stage.number}`}
                className="stage-card p-6 md:p-8 rounded-xl border border-[#0D0D0F]/15 bg-[#F4F3EF] hover:border-[#0D0D0F]/40 transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl md:text-5xl font-display font-black text-[#0D0D0F] tracking-tighter">
                    {stage.number}
                  </span>
                  <span className="text-xs font-mono uppercase tracking-widest text-[#A6A6A6]">
                    Stage {stage.number}
                  </span>
                </div>

                <h3 className="text-2xl md:text-3xl font-display font-black tracking-tighter uppercase text-[#0D0D0F] mb-2">
                  {stage.name}
                </h3>

                <p className="text-sm md:text-base text-[#262629] font-editorial leading-relaxed max-w-xl">
                  {stage.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
