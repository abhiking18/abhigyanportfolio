import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

export default function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const followerRef = useRef<HTMLDivElement>(null);
  const [cursorText, setCursorText] = useState<string>('');
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [isPointer, setIsPointer] = useState<boolean>(false);
  const [isVisible, setIsVisible] = useState<boolean>(false);

  useEffect(() => {
    // Only enable on desktop pointer
    if (window.matchMedia('(pointer: coarse)').matches) return;

    const cursor = cursorRef.current;
    const follower = followerRef.current;
    if (!cursor || !follower) return;

    const pos = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    const mouse = { x: pos.x, y: pos.y };

    const onMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      if (!isVisible) setIsVisible(true);

      gsap.to(cursor, {
        x: mouse.x,
        y: mouse.y,
        duration: 0.08,
        ease: 'power2.out',
      });
    };

    const updateFollower = () => {
      pos.x += (mouse.x - pos.x) * 0.15;
      pos.y += (mouse.y - pos.y) * 0.15;

      gsap.set(follower, {
        x: pos.x,
        y: pos.y,
      });
    };

    gsap.ticker.add(updateFollower);
    window.addEventListener('mousemove', onMouseMove);

    // Track interactive elements
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const interactiveEl = target.closest('a, button, [data-cursor], input, textarea');

      if (interactiveEl) {
        const customText = interactiveEl.getAttribute('data-cursor');
        if (customText) {
          setCursorText(customText);
          setIsHovered(true);
        } else {
          setCursorText('');
          setIsPointer(true);
        }
      } else {
        setCursorText('');
        setIsHovered(false);
        setIsPointer(false);
      }
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    const handleMouseEnter = () => {
      setIsVisible(true);
    };

    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      gsap.ticker.remove(updateFollower);
      window.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseover', handleMouseOver);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [isVisible]);

  return (
    <div className={`pointer-events-none fixed inset-0 z-[9999] transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0'} hidden md:block`}>
      {/* Small Precision Dot */}
      <div
        ref={cursorRef}
        className="fixed top-0 left-0 -ml-1 -mt-1 h-2 w-2 rounded-full bg-white mix-blend-difference pointer-events-none transition-transform duration-100 ease-out"
        style={{ transform: 'translate3d(-100px, -100px, 0)' }}
      />

      {/* Outer Spring Follower */}
      <div
        ref={followerRef}
        className={`fixed top-0 left-0 -ml-6 -mt-6 rounded-full pointer-events-none flex items-center justify-center transition-all duration-300 ease-out mix-blend-difference ${
          isHovered
            ? 'h-20 w-20 -ml-10 -mt-10 bg-white text-[#0D0D0F]'
            : isPointer
            ? 'h-14 w-14 -ml-7 -mt-7 border border-white/60 bg-white/10'
            : 'h-10 w-10 -ml-5 -mt-5 border border-white/40'
        }`}
        style={{ transform: 'translate3d(-100px, -100px, 0)' }}
      >
        {cursorText && (
          <span className="text-[10px] font-bold tracking-widest uppercase text-black font-display select-none">
            {cursorText}
          </span>
        )}
      </div>
    </div>
  );
}
