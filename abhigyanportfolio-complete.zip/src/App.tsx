import { useState } from 'react';
import Preloader from './components/Preloader';
import CustomCursor from './components/CustomCursor';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import CreativeIntroSection from './components/CreativeIntroSection';
import ExperiencePresenceSection from './components/ExperiencePresenceSection';
import SelectedProjects3D from './components/SelectedProjects3D';
import RotatingProjectRing from './components/RotatingProjectRing';
import DevelopmentProcessSection from './components/DevelopmentProcessSection';
import ServicesSection from './components/ServicesSection';
import BuildYourWebsiteSection from './components/BuildYourWebsiteSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import SmoothScroll from './components/SmoothScroll';

export default function App() {
  const [loading, setLoading] = useState(true);

  const handleContactClick = () => {
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <SmoothScroll>
      <div className="relative min-h-screen bg-[#0D0D0F] text-[#EDECE8] overflow-x-hidden selection:bg-[#EDECE8] selection:text-[#0D0D0F]">
        {/* Custom Spring Cursor for Desktop */}
        <CustomCursor />

        {/* Cinematic Preloader */}
        {loading && <Preloader onComplete={() => setLoading(false)} />}

        {/* Global Floating Header */}
        <Navbar onContactClick={handleContactClick} />

        {/* Main Sections Hierarchy */}
        <main className="relative z-10 w-full">
          {/* 02 — Hero Section */}
          <HeroSection />

          {/* 03 — Creative Introduction */}
          <CreativeIntroSection />

          {/* 04 — Experience & Global Presence */}
          <ExperiencePresenceSection />

          {/* 05 — 3D Selected Projects */}
          <SelectedProjects3D />

          {/* 06 — Rotating Project Ring */}
          <RotatingProjectRing />

          {/* 07 — Development Process */}
          <DevelopmentProcessSection />

          {/* 08 — Services */}
          <ServicesSection onContactClick={handleContactClick} />

          {/* NEW: Build Your Website Section */}
          <BuildYourWebsiteSection />

          {/* 09 — Contact */}
          <ContactSection />
        </main>

        {/* Signature Footer */}
        <Footer />
      </div>
    </SmoothScroll>
  );
}
