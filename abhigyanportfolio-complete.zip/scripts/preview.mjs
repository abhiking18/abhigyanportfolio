import puppeteer from 'puppeteer-core';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const artifactDir = 'C:\\Users\\admin\\.gemini\\antigravity\\brain\\359bed24-d152-48ca-8fc6-a5017d6e5379';
const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

async function preview() {
  const browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });
  console.log('Navigating to http://127.0.0.1:3000/ ...');
  await page.goto('http://127.0.0.1:3000/', { waitUntil: 'networkidle0', timeout: 15000 });

  // Wait 3s for preloader animation to finish and curtain to slide up
  await new Promise(r => setTimeout(r, 3200));

  // Capture Hero section
  await page.screenshot({ path: path.join(artifactDir, 'preview-hero.png') });
  console.log('Saved preview-hero.png');

  // Scroll down to About / Philosophy
  await page.evaluate(() => window.scrollBy(0, 1000));
  await new Promise(r => setTimeout(r, 1000));
  await page.screenshot({ path: path.join(artifactDir, 'preview-intro.png') });
  console.log('Saved preview-intro.png');

  // Scroll down to 3D Projects
  await page.evaluate(() => {
    const el = document.getElementById('work');
    if (el) el.scrollIntoView();
  });
  await new Promise(r => setTimeout(r, 1200));
  await page.screenshot({ path: path.join(artifactDir, 'preview-projects.png') });
  console.log('Saved preview-projects.png');

  // Scroll down to Process
  await page.evaluate(() => {
    const el = document.getElementById('process');
    if (el) el.scrollIntoView();
  });
  await new Promise(r => setTimeout(r, 1000));
  await page.screenshot({ path: path.join(artifactDir, 'preview-process.png') });
  console.log('Saved preview-process.png');

  // Mobile Viewport test
  await page.setViewport({ width: 390, height: 844, isMobile: true });
  await page.evaluate(() => window.scrollTo(0, 0));
  await new Promise(r => setTimeout(r, 1000));
  await page.screenshot({ path: path.join(artifactDir, 'preview-mobile-hero.png') });
  console.log('Saved preview-mobile-hero.png');

  await browser.close();
  console.log('All preview captures completed!');
}

preview();
