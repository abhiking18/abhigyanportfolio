import puppeteer from 'puppeteer-core';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, '../public');

const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

const projects = [
  {
    id: 'glo',
    url: 'https://gloclinicdemo1.vercel.app/',
    filename: 'project-glo.png'
  },
  {
    id: 'dhaba',
    url: 'https://chefdhabademo16.vercel.app/',
    filename: 'project-dhaba.png'
  },
  {
    id: 'realestate',
    url: 'https://tarexwebs-sample.netlify.app/',
    filename: 'project-realestate.png'
  },
  {
    id: 'kidzee',
    url: 'https://kidzeedemo.vercel.app/',
    filename: 'project-kidzee.png'
  }
];

async function run() {
  console.log('Launching Chrome from:', chromePath);
  const browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-web-security']
  });

  for (const p of projects) {
    try {
      console.log(`Capturing ${p.id} (${p.url})...`);
      const page = await browser.newPage();
      await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
      await page.goto(p.url, { waitUntil: 'networkidle2', timeout: 25000 });
      await new Promise(r => setTimeout(r, 2000)); // wait for animations to settle
      const outPath = path.join(publicDir, p.filename);
      await page.screenshot({ path: outPath, type: 'png' });
      console.log(`Saved screenshot to ${outPath}`);
      await page.close();
    } catch (err) {
      console.error(`Error capturing ${p.id}:`, err.message);
    }
  }

  await browser.close();
  console.log('Done capturing screenshots!');
}

run();
