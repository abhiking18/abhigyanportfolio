@echo off
cd /d "%~dp0"
echo ========================================================
echo Pushing Abhigyan Kalita Portfolio to GitHub...
echo Repository: https://github.com/abhiking18/abhigyanportfolio.git
echo ========================================================
echo.
git push -u origin main
echo.
if %ERRORLEVEL% equ 0 (
    echo [SUCCESS] Successfully pushed to GitHub!
    echo Check your repository at: https://github.com/abhiking18/abhigyanportfolio
) else (
    echo [ERROR] Push failed. Please check your GitHub login / permissions.
)
echo.
pause
